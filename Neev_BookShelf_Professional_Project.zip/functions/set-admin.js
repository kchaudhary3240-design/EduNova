// Run from the functions folder after `firebase login` and `firebase use <project-id>`.
// Usage: node set-admin.js student@example.com
const admin = require("firebase-admin");
admin.initializeApp();
(async()=>{
  const email=process.argv[2];
  if(!email){console.error("Usage: node set-admin.js email@example.com");process.exit(1);}
  const user=await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid,{...(user.customClaims||{}),admin:true});
  console.log(`Admin role enabled for ${email}. Sign out and sign back in on the website.`);
  process.exit(0);
})().catch(e=>{console.error(e);process.exit(1)});
