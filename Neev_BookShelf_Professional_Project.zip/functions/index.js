const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { setGlobalOptions } = require("firebase-functions/v2");
const admin = require("firebase-admin");
const crypto = require("crypto");
admin.initializeApp();
setGlobalOptions({ region: "asia-south1", maxInstances: 10 });
const db = admin.firestore();
const bucket = admin.storage().bucket();
const now = admin.firestore.FieldValue.serverTimestamp();
const requireUser = req => { if (!req.auth) throw new HttpsError("unauthenticated","Sign in first."); return req.auth.uid; };
const requireAdmin = req => { const uid=requireUser(req); if(req.auth.token.admin!==true) throw new HttpsError("permission-denied","Admin access required."); return uid; };

exports.createProfile = onCall(async req => {
  const uid=requireUser(req); const name=String(req.data?.displayName||"Student").slice(0,60);
  const ref=db.doc(`users/${uid}`);
  await db.runTransaction(async tx=>{const snap=await tx.get(ref);if(!snap.exists)tx.create(ref,{displayName:name,coins:0,unlockedBooks:[],createdAt:now});});
  return {ok:true};
});

exports.createUpload = onCall(async req => {
  const uid=requireUser(req);
  const {title,author,subject,price,fileName,size,contentType}=req.data||{};
  if(typeof title!=="string"||title.trim().length<2||title.length>100)throw new HttpsError("invalid-argument","Enter a valid title.");
  if(typeof author!=="string"||author.trim().length<1||author.length>80)throw new HttpsError("invalid-argument","Enter an author.");
  if(!["Physics","Chemistry","Mathematics","Computer Science","Biology","English","Sample Paper","Other"].includes(subject))throw new HttpsError("invalid-argument","Choose a valid subject.");
  if(![5,10,15,20].includes(Number(price)))throw new HttpsError("invalid-argument","Choose a valid coin price.");
  if(!Number.isInteger(size)||size<1||size>10*1024*1024||contentType!=="application/pdf"||!String(fileName||"").toLowerCase().endsWith(".pdf"))throw new HttpsError("invalid-argument","Only PDF files up to 10 MB are allowed.");
  const recent=await db.collection("books").where("ownerId","==",uid).get();
  if(recent.size>=30)throw new HttpsError("resource-exhausted","Upload limit reached.");
  const bookRef=db.collection("books").doc();
  const uploadPath=`pdfs/${uid}/${bookRef.id}.pdf`;
  await bookRef.set({title:title.trim(),author:author.trim(),subject,price:Number(price),ownerId:uid,ownerName:req.auth.token.name||req.auth.token.email||"Student",status:"pending",kind:subject==="Sample Paper"?"SAMPLE PAPER":"PDF RESOURCE",uploadPath,fileName:String(fileName).slice(0,160),size,contentType,createdAt:admin.firestore.FieldValue.serverTimestamp(),reviewedAt:null});
  return {bookId:bookRef.id,uploadPath};
});

exports.finishUpload = onCall(async req => {
  const uid=requireUser(req);const bookId=String(req.data?.bookId||"");
  const ref=db.doc(`books/${bookId}`);const snap=await ref.get();
  if(!snap.exists||snap.data().ownerId!==uid)throw new HttpsError("permission-denied","Upload not found.");
  const b=snap.data();const file=bucket.file(b.uploadPath);const [exists]=await file.exists();
  if(!exists)throw new HttpsError("failed-precondition","PDF upload did not complete.");
  const [meta]=await file.getMetadata();
  if(Number(meta.size)>10*1024*1024||meta.contentType!=="application/pdf"){await file.delete().catch(()=>{});await ref.delete();throw new HttpsError("invalid-argument","Invalid PDF file.");}
  await ref.update({status:"pending",uploadedAt:admin.firestore.FieldValue.serverTimestamp()});
  return {ok:true};
});

exports.reviewUpload = onCall(async req => {
  requireAdmin(req);const bookId=String(req.data?.bookId||"");const decision=req.data?.decision;
  if(!["approve","reject"].includes(decision))throw new HttpsError("invalid-argument","Invalid review decision.");
  const bookRef=db.doc(`books/${bookId}`);
  await db.runTransaction(async tx=>{
    const snap=await tx.get(bookRef);if(!snap.exists)throw new HttpsError("not-found","Upload not found.");
    const b=snap.data();if(b.status!=="pending")throw new HttpsError("failed-precondition","This upload has already been reviewed.");
    if(decision==="approve"){
      const userRef=db.doc(`users/${b.ownerId}`);const userSnap=await tx.get(userRef);
      if(!userSnap.exists)tx.create(userRef,{displayName:b.ownerName||"Student",coins:5,unlockedBooks:[],createdAt:now});
      else tx.update(userRef,{coins:admin.firestore.FieldValue.increment(5)});
      tx.update(bookRef,{status:"approved",reviewedAt:now,reviewedBy:req.auth.uid,coinsAwarded:5});
    }else tx.update(bookRef,{status:"rejected",reviewedAt:now,reviewedBy:req.auth.uid,coinsAwarded:0});
  });
  return {ok:true};
});

exports.unlockBook = onCall(async req => {
  const uid=requireUser(req);const bookId=String(req.data?.bookId||"");const bookRef=db.doc(`books/${bookId}`);const userRef=db.doc(`users/${uid}`);const unlockRef=db.doc(`users/${uid}/unlocks/${bookId}`);
  await db.runTransaction(async tx=>{
    const [bookSnap,userSnap,unlockSnap]=await Promise.all([tx.get(bookRef),tx.get(userRef),tx.get(unlockRef)]);
    if(!bookSnap.exists||bookSnap.data().status!=="approved")throw new HttpsError("not-found","This book is unavailable.");
    const book=bookSnap.data();if(book.ownerId===uid||unlockSnap.exists)return;
    if(!userSnap.exists)throw new HttpsError("failed-precondition","Create your profile first.");
    const user=userSnap.data();const cost=Number(book.price||10);if((user.coins||0)<cost)throw new HttpsError("failed-precondition",`You need ${cost} coins.`);
    tx.update(userRef,{coins:admin.firestore.FieldValue.increment(-cost),unlockedBooks:admin.firestore.FieldValue.arrayUnion(bookId)});
    tx.create(unlockRef,{bookId,title:book.title,subject:book.subject,price:cost,unlockedAt:now});
  });
  return {ok:true};
});

exports.getReaderUrl = onCall(async req => {
  const uid=requireUser(req);const bookId=String(req.data?.bookId||"");const bookRef=db.doc(`books/${bookId}`);const snap=await bookRef.get();
  if(!snap.exists)throw new HttpsError("not-found","Resource not found.");const b=snap.data();
  if(b.status!=="approved"&&b.ownerId!==uid)throw new HttpsError("permission-denied","Resource not approved.");
  if(b.ownerId!==uid){const unlock=await db.doc(`users/${uid}/unlocks/${bookId}`).get();if(!unlock.exists)throw new HttpsError("permission-denied","Unlock this book first.");}
  const file=bucket.file(b.uploadPath);const [exists]=await file.exists();if(!exists)throw new HttpsError("not-found","PDF file is missing.");
  const [url]=await file.getSignedUrl({action:"read",expires:Date.now()+5*60*1000});
  return {url,title:b.title};
});

/* Set admin access from a trusted environment, never from the website UI:
   node set-admin.js student@example.com */
