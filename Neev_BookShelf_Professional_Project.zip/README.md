# Neev BookShelf — Professional School Project

A responsive student digital library with animated floating-book background, email/password login, PDF submissions, admin approval, a 5-coin reward for each approved upload, coin-priced book unlocks, and an in-page PDF reader.

## Important: this is a real Firebase-backed starter, not a no-setup static HTML demo

The frontend uses Firebase Authentication, Firestore, Cloud Storage and callable Cloud Functions. It is designed so that coin balances and unlocks are changed by trusted backend functions, not by browser JavaScript.

## Features

- Mobile-first professional UI with animated books and reduced-motion support.
- Student account creation and sign-in.
- Upload PDF up to 10 MB; submissions begin in `pending` status.
- Admin-only review queue; approval adds exactly 5 coins once.
- Book price choices: 5, 10, 15 or 20 coins.
- Server-side coin deduction and per-user unlock records.
- Short-lived signed PDF URLs and PDF.js in-page reader.
- Search, subject filters, sorting, upload status and unlocked list.

## 1. Create and configure Firebase

1. Go to https://console.firebase.google.com/ and create a project.
2. Add a Web App and copy its Firebase config into `public/app.js` in the `firebaseConfig` object.
3. In Firebase Authentication, enable **Email/Password**.
4. Create a **Cloud Firestore** database.
5. Enable **Cloud Storage**.
6. Upgrade the Firebase project to the plan required for Cloud Functions and deploy them. Cloud Functions deployment may require the Blaze billing plan. Set budget alerts before testing.
7. Install Node.js 20 and Firebase CLI: `npm install -g firebase-tools`.
8. In the project directory, run:
   ```bash
   firebase login
   firebase use --add
   cd functions
   npm install
   cd ..
   firebase deploy --only firestore:rules,storage,functions,hosting
   ```

## 2. Enable the first admin

1. Create your account through the website first.
2. In a terminal at the project root, run:
   ```bash
   cd functions
   node set-admin.js your-admin-email@example.com
   ```
3. Sign out and sign back in on the website. Admin role is stored as a Firebase custom claim and cannot be granted by editing browser data.

The account must already exist. Never expose service-account credentials or run the admin script in frontend code.

## 3. Test the flow

1. Create a student account.
2. Upload a permitted PDF. It will show as pending and no coins are awarded yet.
3. Sign in with the admin account and approve the upload in **Review queue**.
4. The uploader's balance should increase by 5 coins.
5. Unlock an approved book using coins, then open it in the in-page reader.
6. Try the same unlock again; the user should not be charged twice.

## Project structure

- `public/index.html` — page layout
- `public/styles.css` — responsive styling and motion background
- `public/app.js` — frontend and Firebase integration
- `functions/index.js` — trusted upload, approval, coin, unlock and reader URL logic
- `functions/set-admin.js` — one-time admin setup helper
- `firestore.rules`, `storage.rules` — access control

## School-project notes and responsible use

- Upload only PDFs you own or have permission to distribute. Avoid sharing copyrighted textbooks or personal information.
- The PDF reader is intended to display a document in the page; it is not DRM and cannot guarantee screenshots or copying are impossible.
- Before real school-wide use, add an abuse-report process, upload rate limits, content review policy, and test the rules with the Firebase Emulator Suite.
- The initial sample book cards from the original mockup are intentionally not seeded; the library shows approved, real uploads.
- This project needs your Firebase configuration and deployment to work online. Opening `index.html` directly will not activate Firebase.
